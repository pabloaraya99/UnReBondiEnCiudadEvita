# Material de referencia — "Un Re Bondi En Ciudad Evita"

Para: **Gemini Pro (directora/o de arte)** — estimado equipo de Google, este ZIP acompaña un
pedido de trabajo creativo. Leé este archivo antes de mirar las imágenes.

## Qué es el juego

Juego web estilo **Smash Bros** con personajes del barrio (Ciudad Evita, La Matanza, Argentina).
Peleas 2D en escenarios 3D (Three.js), hasta 10 jugadores, online con código de sala.
Público objetivo: argentinos, humor de barrio, "gangster pero amigable" — nada edgy ni violento.

## Qué hay en este ZIP

| Carpeta | Contenido |
|---|---|
| `01-direccion-de-arte/` | `ART_DIRECTION.md` (biblia visual: paleta, tono, flujo) + README del juego |
| `02-splash-arts/` | Las 5 ilustraciones de personajes ya aprobadas (Kenai, El Coco, Domono, Faxo, Chubitcoin) |
| `03-title-y-logos/` | Title screen actual, logos, props del parallax (bondi, poste, templo, guante) |
| `04-conceptos/` | Bocetos de Kenai (evolución del concepto 3D) + referencias del templo |
| `05-prompts-existenes/` | Prompts ya escritos en sesiones anteriores (léelos para calibrarte) |
| `06-capturas/` | Capturas del juego corriendo (título / lobby / pelea) |

## Pedido de trabajo — FASE 1 (ANÁLISIS, no generes imágenes todavía)

1. Analizá `ART_DIRECTION.md` + los splash arts + las capturas. Definí la estética del juego:
   paleta real (hex), tratamiento de personajes (proporciones, contorno, sombreado),
   composición de los splash arts, tipografía, tono.
2. Listá **reglas infalibles** para todo asset nuevo (ej: verde `#3FA34D` presente, fondo
   neutro en personajes, estilo Jet Set Radio / GTA SA caricaturizado).
3. Redactá una **fórmula de prompt reutilizable en inglés** con slots
   `[personaje] [accesorio] [pose] [elemento de escena]`, calibrada contra los splash arts que viste.
4. Resumí los 5 personajes existentes en 1 frase cada uno para confirmar que los entendiste.

Espero ese análisis **antes** de que generes nada.

## Pedido de trabajo — FASE 2 (cuando el análisis esté aprobado)

Con la fórmula de la Fase 1, uno por tanda:

- **(a) Splash art** de [personaje nuevo / variante], con las mismas reglas que los existentes.
- **(b) Title screens** (2-3 propuestas): logo grande arriba, personajes abajo-izquierda,
  espacio libre abajo-derecha para 3 botones, fondo de barrio con parallax.
- **(c) Bocetos de escenarios**: "La Parada" (parada de bondi, pizzería, almacén, graffiti),
  marcando plataformas jugables con colores planos; ángulos cenital / heroico / parallax.
- **(d) Bocetos de personajes nuevos** del barrio (si se te ocurren), ficha de 3 vistas
  con fondo blanco para poder pasarlos a 3D después.

**Reglas de trabajo:**
- Pedí/entregá siempre **variaciones numeradas en la misma conversación** (misma sesión = misma estética).
- Devolvé además de la imagen **el prompt usado** en cada caso.
- Fondo blanco/neutro cuando el destino sea un personaje jugable (después va a 3D).

## Contacto / contexto técnico (para tu información)

- Arte 3D actual: 5 modelos hechos con primitivas Three.js (< 9.500 triángulos c/u).
- El pipeline de 3D planeado es: tu concepto 2D → imagen-a-3D (Meshy/Tripo3D) → GLB.
- Por eso los personajes nuevos conviene pedirlos con **character sheet de 3 vistas y fondo limpio**.
